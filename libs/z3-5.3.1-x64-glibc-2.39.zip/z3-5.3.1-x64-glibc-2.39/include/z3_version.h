// automatically generated file.
#define Z3_MAJOR_VERSION   5
#define Z3_MINOR_VERSION   3
#define Z3_BUILD_NUMBER    1
#define Z3_REVISION_NUMBER 0

#define Z3_FULL_VERSION    "5.3.1.0 ac9156f97cb44e56472e1c841f7a2beb1e976b24"
#define Z3GITHASH ac9156f97cb44e56472e1c841f7a2beb1e976b24
